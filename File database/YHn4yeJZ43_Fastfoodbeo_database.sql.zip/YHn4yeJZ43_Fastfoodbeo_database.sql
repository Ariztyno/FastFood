-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 23, 2019 at 02:48 AM
-- Server version: 8.0.13-4
-- PHP Version: 7.2.19-0ubuntu0.18.04.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `YHn4yeJZ43`
--
CREATE DATABASE IF NOT EXISTS `YHn4yeJZ43` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `YHn4yeJZ43`;

-- --------------------------------------------------------

--
-- Table structure for table `cthoadon`
--

CREATE TABLE IF NOT EXISTS `cthoadon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `MaHD` int(11) NOT NULL,
  `MaSP` int(11) NOT NULL,
  `TenSP` varchar(20000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `SL` int(20) NOT NULL,
  `Gia` int(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cthoadon`
--

INSERT INTO `cthoadon` (`id`, `MaHD`, `MaSP`, `TenSP`, `SL`, `Gia`) VALUES
(1, 8, 5, 'CÁ KHO TIÊU', 1, 35000),
(2, 8, 4, '7-UP', 1, 10000),
(3, 9, 3, 'CÁ VIÊN', 10, 360000),
(4, 9, 6, 'CÁ RÁN PHÔ MAI', 5, 175000),
(5, 9, 5, 'CÁ KHO TIÊU', 1, 35000),
(6, 9, 4, '7-UP', 16, 160000),
(7, 14, 6, 'CÁ RÁN PHÔ MAI', 8, 280000),
(8, 18, 6, 'CÁ RÁN PHÔ MAI', 13, 455000),
(9, 18, 7, 'SPTEST', 1, 10000),
(10, 19, 6, 'CÁ RÁN PHÔ MAI', 13, 455000),
(11, 19, 7, 'SPTEST', 1, 10000),
(12, 20, 6, 'CÁ RÁN PHÔ MAI', 13, 455000),
(13, 20, 7, 'SPTEST', 1, 10000),
(14, 0, 7, 'sptest', 1, 10000),
(15, 0, 7, 'sptest', 1, 10000),
(16, 25, 9, 'MIRINDA KEM', 1, 10000),
(17, 27, 10, 'MỲ Ý', 1, 40000),
(18, 28, 5, 'CÁ KHO TIÊU', 1, 35000),
(19, 28, 10, 'MỲ Ý', 1, 40000),
(20, 29, 5, 'CÁ KHO TIÊU', 5, 175000),
(21, 29, 10, 'MỲ Ý', 3, 120000);

-- --------------------------------------------------------

--
-- Table structure for table `hoadon`
--

CREATE TABLE IF NOT EXISTS `hoadon` (
  `MaHD` int(11) NOT NULL AUTO_INCREMENT,
  `HoTenKH` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `SDT` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `GioiTinh` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `DiaChi` varchar(10000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `NgayDat` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `NgayGiao` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Combo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TinhTrang` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`MaHD`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `hoadon`
--

INSERT INTO `hoadon` (`MaHD`, `HoTenKH`, `SDT`, `GioiTinh`, `DiaChi`, `NgayDat`, `NgayGiao`, `Combo`, `TinhTrang`) VALUES
(4, 'cxvxc', '0202020', 'Nữ', 'sdfsdfsdfsdf', '06 / 08 / 2019', '20190807', 'Nước lọc, khăn giấy và tăm xỉa răng', 'Chưa giao'),
(5, 'kjdjhfkjdbkfjkdfsdfds', '02020202', 'Nữ', 'skjdfkjhdkjsfdsfds', '08 / 08 / 2019', '20190809', 'Nước lọc, khăn giấy và tăm xỉa răng', 'Chưa giao'),
(6, 'asdas', '5050505', 'Nữ', 'sdfsdfsdfsdf', '08 / 08 / 2019', '20190809', 'Nước lọc', 'Chưa giao'),
(7, 'sdsfsdfsd', '15651561', 'Nữ', 'sdjfkjsdfsdfdsf', '08 / 08 / 2019', '20190809', 'Nước lọc', 'Chưa giao'),
(10, 'Minh', '0900', 'Nữ', 'Binh chanh', '22 / 08 / 2019', '2019-08-23', 'Nước lọc, khăn giấy và tăm xỉa răng', 'Chưa giao'),
(11, 'Minh', '0900', 'Nữ', 'Binh chanh', '22 / 08 / 2019', '2019-08-23', 'Nước lọc, khăn giấy và tăm xỉa răng', 'Chưa giao'),
(12, 'Minh', '0900', 'Nữ', 'Binh chanh', '22 / 08 / 2019', '2019-08-23', 'Nước lọc, khăn giấy và tăm xỉa răng', 'Chưa giao'),
(13, 'Minh', '0900', 'Nữ', 'Binh chanh', '22 / 08 / 2019', '2019-08-23', 'Nước lọc, khăn giấy và tăm xỉa răng', 'Chưa giao'),
(14, 'miminh', '02120212', 'Nam', 'dfbjdfsdsfsdf', '22 / 08 / 2019', '2019-08-23', 'Nước lọc, khăn giấy và tăm xỉa răng', 'Chưa giao'),
(15, 'min', '090215651', 'Nam', 'ugsubfbsdjkfsdfsdf', '22 / 08 / 2019', '2019-08-23', 'Nước lọc', 'Chưa giao'),
(16, 'min', '090215651', 'Nam', 'ugsubfbsdjkfsdfsdf', '22 / 08 / 2019', '2019-08-23', 'Nước lọc', 'Chưa giao'),
(17, 'min', '090215651', 'Nam', 'ugsubfbsdjkfsdfsdf', '22 / 08 / 2019', '2019-08-23', 'Nước lọc', 'Chưa giao'),
(18, 'min', '090215651', 'Nam', 'ugsubfbsdjkfsdfsdf', '22 / 08 / 2019', '2019-08-23', 'Nước lọc', 'Chưa giao'),
(19, 'min', '090215651', 'Nam', 'ugsubfbsdjkfsdfsdf', '22 / 08 / 2019', '2019-08-23', 'Nước lọc', 'Chưa giao'),
(20, 'min', '090215651', 'Nam', 'ugsubfbsdjkfsdfsdf', '22 / 08 / 2019', '2019-08-23', 'Nước lọc', 'Chưa giao'),
(21, 'NguyenTrung Tin', '090000', 'Nam', 'Binh Thanh', '2019-08-22', '2019-08-22', 'Nước lọc, khăn giấy và tăm xỉa răng', 'Chưa giao'),
(22, 'NguyenTrung Tin', '090000', 'Nam', 'Binh Thanh', '2019-08-22', '2019-08-22', 'Nước lọc, khăn giấy và tăm xỉa răng', 'Chưa giao'),
(23, 'minh', '0900', 'Nữ', 'minh', '2019-08-22', '2019-08-22', 'Nước lọc', 'Chưa giao'),
(24, 'GGGGGDFGDF', '8768565', 'Nữ', 'FGFD', '2019-08-22', '2019-08-22', 'Nước lọc', 'Chưa giao'),
(25, 'fsdfsd', '7878', 'Nam', 'nkdsk', '2019-08-22', '2019-08-23', 'Khăn giấy và tăm xỉa răng', 'Chưa giao'),
(26, 'minh123', '123456789', 'Nữ', 'djdfgbjkdfgfdgdfgdfg', '2019-08-23', '2019-08-24', 'Nước lọc, khăn giấy và tăm xỉa răng', 'Chưa giao'),
(27, 'minh123', '123456789', 'Nữ', 'djdfgbjkdfgfdgdfgdfg', '2019-08-23', '2019-08-24', 'Nước lọc, khăn giấy và tăm xỉa răng', 'Chưa giao'),
(28, 'ngubo', '123456789', 'Nữ', 'kjdfnkjffsdfdsfsdfdsdf', '2019-08-23', '2019-08-24', ' ', 'Chưa giao'),
(29, 'jkhfkjdf', '123456789', 'Nam', 'djfbkjfsf', '2019-08-23', '2019-08-24', 'Nước lọc', 'Đã hoàn thành');

-- --------------------------------------------------------

--
-- Table structure for table `loaisp`
--

CREATE TABLE IF NOT EXISTS `loaisp` (
  `MaLoai` int(11) NOT NULL AUTO_INCREMENT,
  `TenLoai` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Hinh` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`MaLoai`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `loaisp`
--

INSERT INTO `loaisp` (`MaLoai`, `TenLoai`, `Hinh`) VALUES
(1, 'Thức ăn', 'https://i.imgur.com/05khabB.png'),
(2, 'Nước uống', 'https://i.imgur.com/tp71oJR.png');

-- --------------------------------------------------------

--
-- Table structure for table `sp`
--

CREATE TABLE IF NOT EXISTS `sp` (
  `MaSP` int(11) NOT NULL AUTO_INCREMENT,
  `TenSP` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Gia` int(15) NOT NULL,
  `Hinh` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `MoTa` varchar(10000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `TinhTrang` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `MaLoai` int(11) NOT NULL,
  PRIMARY KEY (`MaSP`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sp`
--

INSERT INTO `sp` (`MaSP`, `TenSP`, `Gia`, `Hinh`, `MoTa`, `TinhTrang`, `MaLoai`) VALUES
(1, 'GÀ HOT WINGS LẮC VỊ ZABB THÁI', 20000, 'https://kfcvietnam.com.vn/uploads/combo/7492da89fb2aa34b9d6b4b67537e3f03.png', 'Cánh gà giòn cay', 'Còn hàng', 1),
(2, 'PEPSI', 10000, 'https://images-na.ssl-images-amazon.com/images/I/41qU2ZfXinL._SY300_QL70_.jpg', 'Nước ngọt cá gas', 'Hết hàng', 2),
(3, 'CÁ VIÊN', 30000, 'https://ameovat.com/wp-content/uploads/2018/04/cach-lam-ca-vien-chien-5-600x398.jpg', 'Cá viên chiên', 'Còn hàng', 1),
(4, '7-UP', 10000, 'https://nuocgiaikhatgiasi.com/wp-content/uploads/2018/04/7up-sleek-330ml-2-1.jpg', 'Nước ngọt cá gas', 'Còn hàng', 2),
(5, 'CÁ KHO TIÊU gwgwqjewj', 35000, 'https://media.ex-cdn.com/EXP/media.phunutoday.vn/files/upload_images/2016/08/19/cach-lam-mon-ca-kho-tieu-thom-ngon-don-gian-tai-nha-1-phunutoday_vn.jpg', 'Cá kho với tiêu', 'Còn hàng', 1),
(6, 'CÁ RÁN PHÔ MAI', 35000, 'https://vuabien.com/datafiles/3/2019-01-11/15471787252549_ca-ngu-nuong-pho-mai.jpg', 'Cá rán nóng chấm với sốt phô mai', 'Còn hàng', 1),
(7, 'SPTEST', 10000, 'https://www.ohhowcivilized.com/wp-content/uploads/2018/06/0618-iced-matcha-latte-11.jpg', 'Matcha ice cream', 'Còn hàng', 1),
(8, 'KEM', 10000, 'https://namvietluat.vn/wp-content/uploads/2018/05/m%E1%BB%9F-c%E1%BB%ADa-h%C3%A0ng-kinh-doanh-kem-t%C6%B0%C6%A1i-2.jpg', 'Kem tươi nhiều hương vị.', 'Hết hàng', 1),
(9, 'MIRINDA KEM', 10000, 'https://media-ak.static-adayroi.com/sys_master/images/h47/h41/15564637995038.jpg', 'Mirinda hương kem chanh.', 'Còn hàng', 2),
(10, 'MỲ Ý', 40000, 'https://cdn.huongnghiepaau.com/wp-content/uploads/2019/01/my-y-chay.jpg', 'Mỳ ý sốt cà chua bò hầm.', 'Còn hàng', 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
